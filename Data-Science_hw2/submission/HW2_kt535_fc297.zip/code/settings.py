RATINGS_10M = './ml-10M100K/ratings.dat'
MOVIES_10M = './ml-10M100K/movies.dat'
RATINGS_22M = './ml-latest/ratings.csv'
MOVIES_22M = './ml-latest/movies.csv'
MSD = './train_triplets.txt'
DATA_FOLDER = './ml-10M100K'

